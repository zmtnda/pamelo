INSERT INTO Users
(id, email, password, role, firstName, lastName, phone, whenRegistered)
VALUES (1, "Admin@11.com", "password", 2, "Admin", "IAM", 123456789, NOW());
